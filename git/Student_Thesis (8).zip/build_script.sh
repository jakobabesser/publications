#!/bin/sh
bfname="`basename "$1" .tex`"
pdflatex "$1"
bibtex "$bfname"
#makeindex "$bfname".nlo -s nomencl.ist -o "$bfname".nls
makeindex "$bfname".glo -s nomencl.ist -o "$bfname".gls
pdflatex "$1"
pdflatex "$1"
pdflatex "$1"
evince "$bfname".pdf & 

#pdflatex -interaction=nonstopmode %.tex|bibtex %.aux|pdflatex -interaction=nonstopmode %.tex|pdflatex -interaction=nonstopmode %.tex