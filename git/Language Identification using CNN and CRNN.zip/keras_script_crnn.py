#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 13 12:51:43 2020

@author: dragaa
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 27 13:23:18 2020

@author: dragaa
"""

from tensorflow.keras.layers import Dense, Convolution2D, BatchNormalization, MaxPooling2D, GlobalMaxPooling2D, Flatten, Bidirectional, Permute, Reshape, LSTM
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.models import Sequential
from tensorflow.keras.callbacks import CSVLogger
from my_classes import DataGenerator
#from keras import backend as K
from tensorflow.keras import backend as K
from tensorflow.keras.regularizers import l2
import numpy as np
import pandas as pd
K.set_image_data_format("channels_last")
import pickle
from sklearn.metrics import classification_report, confusion_matrix
#import os
#os.environ['TF_CPP_MIN_LOG_LEVEL']='2'

# Parameters
params = {'dim': (200, 129),
          'batch_size': 4,
          'n_classes': 4,
          'n_channels': 1,
          'shuffle': False}



optimizer = Adam(lr=0.00001, decay=1e-4)


# Datasets (choose train & validation file locations)

#Youtube dataset generator
#train_files = pd.read_csv("/home/dragaa/workspace/python_git/pythonrepo/idmt/projects/machine_listening/crnn/youtube_training.csv")
#validation_files = pd.read_csv("/home/dragaa/workspace/python_git/pythonrepo/idmt/projects/machine_listening/crnn/youtube_validation.csv")

#Youtube 6languages dataset generator
#train_files = pd.read_csv("/home/dragaa/workspace/python_git/pythonrepo/idmt/projects/machine_listening/crnn/youtube_6l_training.csv")
#validation_files = pd.read_csv("/home/dragaa/workspace/python_git/pythonrepo/idmt/projects/machine_listening/crnn/youtube_6l_validation.csv")

#EU Repo dataset generator
train_files = pd.read_csv("/home/dragaa/workspace/python_git/pythonrepo/idmt/projects/machine_listening/crnn/eu_repo_training.csv")
validation_files = pd.read_csv("/home/dragaa/workspace/python_git/pythonrepo/idmt/projects/machine_listening/crnn/eu_repo_validation.csv")


train = train_files.file.tolist()
train_labels = train_files.label.tolist()
validation = validation_files.file.tolist()
validation_labels = validation_files.label.tolist()

num_of_train_samples = len(train)
num_of_test_samples = len(validation)

weight_decay = 0.01     #0.001
epochs = 1
batch_size = 4


# Generators
training_generator = DataGenerator(train_files,train_labels, **params)
validation_generator = DataGenerator(validation_files,validation_labels, **params)

# Design model
model = Sequential()
# Architecture
shape_in= [200,129, 1]

model.add(Convolution2D(64, (3, 3),  kernel_regularizer=l2(weight_decay), padding='same', activation="relu", input_shape=shape_in))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same'))

model.add(Convolution2D(128, (3, 3), kernel_regularizer=l2(weight_decay), padding='same', activation="relu" ))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same'))

model.add(Convolution2D(256, (3, 3), kernel_regularizer=l2(weight_decay), padding='same', activation="relu"))
model.add(BatchNormalization())
# model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2)))

model.add(Convolution2D(256, (3, 3), kernel_regularizer=l2(weight_decay), padding='same', activation="relu"))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same'))

model.add(Convolution2D(512, (3, 3), kernel_regularizer=l2(weight_decay),padding='same', activation="relu"))
model.add(BatchNormalization())
# model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2)))

model.add(Convolution2D(512, (3, 3),kernel_regularizer=l2(weight_decay), padding='same', activation="relu"))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same'))

model.add(Convolution2D(512, (3, 3), kernel_regularizer=l2(weight_decay), padding='same', activation="relu"))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same'))



  # (bs, y, x, c) --> (bs, x, y, c)
model.add(Permute((2, 1, 3)))

 # (bs, x, y, c) --> (bs, x, y * c)
bs, x, y, c = model.layers[-1].output_shape
model.add(Reshape((x, y*c)))

model.add(Bidirectional(LSTM(256, return_sequences=False), merge_mode="concat"))
model.add(Dense(4, activation="softmax"))

#run_opts = tf.RunOptions(report_tensor_allocations_upon_oom = True)

model.compile(loss='categorical_crossentropy', optimizer=optimizer,
                   metrics=['accuracy'])
model.summary()
# Train model on dataset
csv_logger = CSVLogger('/home/avdata/xtract/dragaa/machine_listening/datagenerator-cnn-results/log-eu.csv', append=True, separator=';') #save results in csv


model.fit_generator(generator=training_generator,  steps_per_epoch=num_of_train_samples // batch_size,
                    validation_data=validation_generator,  validation_steps=num_of_test_samples // batch_size,
                    use_multiprocessing=True, shuffle = False,
                    workers=1,  epochs=500, max_queue_size=10, callbacks=[csv_logger], verbose=1)
