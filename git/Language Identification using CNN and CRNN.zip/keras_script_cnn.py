#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 27 13:23:18 2020

@author: dragaa
"""

from tensorflow.keras.layers import Dense, Convolution2D, BatchNormalization, MaxPooling2D, GlobalMaxPooling2D, Flatten
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.models import Sequential
from tensorflow.keras.callbacks import CSVLogger
import tensorflow.keras as keras
from my_classes import DataGenerator
#from keras import backend as K
from tensorflow.keras import backend as K
from tensorflow.keras.regularizers import l2
import numpy as np
import pandas as pd
K.set_image_data_format("channels_last")
import pickle
from sklearn.metrics import classification_report, confusion_matrix
#import os
#os.environ['TF_CPP_MIN_LOG_LEVEL']='2'

# Parameters
params = {'dim': (200, 129),
          'batch_size': 32,
          'n_classes': 4,
          'n_channels': 1,
          'shuffle': False}



optimizer = Adam(lr=0.00001, decay=1e-4)

# Datasets (choose train & validation file locations)

#Youtube dataset generator
train_files = pd.read_csv("/home/dragaa/workspace/python_git/pythonrepo/idmt/projects/machine_listening/crnn/youtube_training.csv")
validation_files = pd.read_csv("/home/dragaa/workspace/python_git/pythonrepo/idmt/projects/machine_listening/crnn/youtube_validation.csv")

#Youtube 6languages dataset generator
#train_files = pd.read_csv("/home/dragaa/workspace/python_git/pythonrepo/idmt/projects/machine_listening/crnn/youtube_6l_training.csv")
#validation_files = pd.read_csv("/home/dragaa/workspace/python_git/pythonrepo/idmt/projects/machine_listening/crnn/youtube_6l_validation.csv")

#EU Repo dataset generator
#train_files = pd.read_csv("/home/dragaa/workspace/python_git/pythonrepo/idmt/projects/machine_listening/crnn/eu_repo_training.csv")
#validation_files = pd.read_csv("/home/dragaa/workspace/python_git/pythonrepo/idmt/projects/machine_listening/crnn/eu_repo_validation.csv")

train = train_files.file.tolist()
train_labels = train_files.label.tolist()
validation = validation_files.file.tolist()
validation_labels = validation_files.label.tolist()

num_of_train_samples = len(train)
num_of_test_samples = len(validation)

weight_decay = 0.01     #0.001
epochs = 1
batch_size = 32


# Generators
training_generator = DataGenerator(train_files,train_labels, **params)
validation_generator = DataGenerator(validation_files,validation_labels, **params)

# Design model
model = Sequential()
# Architecture
shape_in= [200,129, 1]

model.add(Convolution2D(64, (3, 3),  kernel_regularizer=l2(weight_decay), padding='same', activation="relu", input_shape=shape_in))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same'))

model.add(Convolution2D(128, (3, 3), kernel_regularizer=l2(weight_decay), padding='same', activation="relu" ))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same'))

model.add(Convolution2D(256, (3, 3), kernel_regularizer=l2(weight_decay), padding='same', activation="relu"))
model.add(BatchNormalization())
# model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2)))

model.add(Convolution2D(256, (3, 3), kernel_regularizer=l2(weight_decay), padding='same', activation="relu"))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same'))

model.add(Convolution2D(512, (3, 3), kernel_regularizer=l2(weight_decay),padding='same', activation="relu"))
model.add(BatchNormalization())
# model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2)))

model.add(Convolution2D(512, (3, 3),kernel_regularizer=l2(weight_decay), padding='same', activation="relu"))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same'))

model.add(Convolution2D(512, (3, 3), kernel_regularizer=l2(weight_decay), padding='same', activation="relu"))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same'))


#model.add(Flatten())
model.add(GlobalMaxPooling2D())
model.add(Dense(1024, kernel_regularizer=l2(weight_decay), activation="relu"))

model.add(Dense(4, activation="softmax"))

#run_opts = tf.RunOptions(report_tensor_allocations_upon_oom = True)

model.compile(loss='categorical_crossentropy', optimizer=optimizer,
                   metrics=['accuracy'])
model.summary()
# Train model on dataset
csv_logger = CSVLogger('/home/avdata/xtract/dragaa/machine_listening/microphone_mismatch/datagenerator-cnn-results/log-youtube.csv', append=True, separator=';') #save results in csv





model.fit_generator(generator=training_generator,  steps_per_epoch = 100,
                    validation_data=validation_generator,  validation_steps = 100,
                    use_multiprocessing=True, shuffle = False,
                    workers=1,  epochs=400, max_queue_size=10, callbacks=[csv_logger], verbose=1)


#pred= model.predict_generator(validation_generator, num_of_test_samples // batch_size, workers=1, use_multiprocessing=True)
#predicted_class_indices=np.argmax(pred,axis=1)
#labels = (validation_generator.labels)
##print(labels)
#
#predictions = [labels[k] for k in predicted_class_indices]
#print(predicted_class_indices)
#print(len(predicted_class_indices))
##print(len(labels))
#print(len(predictions))


#
#y_true = validation_generator.labels
#y_pred = np.argmax(model.predict_generator(validation_generator, steps= len(validation_generator)), axis=1)
#
#print(len(validation_generator.labels))
#print(len(validation_generator))
#print(len(y_pred))
#
#print('Confusion Matrix')
#print(confusion_matrix(y_true, y_pred))




#x = validation_generator
#print(x.labels)
#print(len(x.labels))
#print(len(x))
#print(validation_generator)
#Confution Matrix and Classification Report
#Y_pred = model.predict_generator(validation_generator, num_of_test_samples // batch_size+1)
#y_pred = np.argmax(Y_pred, axis=1)
#print(len(y_pred))
#print(len(validation_generator.labels))
#print('Confusion Matrix')
#print(confusion_matrix(validation_generator.labels, y_pred))
#print('Classification Report')
#target_names = ['0', '1', '2', '3']
#print(classification_report(validation_generator.labels, y_pred, target_names=target_names))

#batch_size = 40
##Confution Matrix
#Y_pred = model.predict_generator(validation_generator, len(validation) // batch_size+1)
#y_pred = np.argmax(Y_pred, axis=1)
#print('Confusion Matrix')
#print(confusion_matrix(validation_generator.labels, y_pred))
#
#target_names = ['0', '1', '2', '3']
#print(classification_report(validation_labels, y_pred, target_names=target_names))

